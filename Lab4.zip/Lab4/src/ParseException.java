/**
 * Throw when encounter a parse error.
 * 
 * @author Naeem Shareef
 */
public class ParseException extends Exception
{
	private static final long serialVersionUID = 1L;
	// Do not add code
}
